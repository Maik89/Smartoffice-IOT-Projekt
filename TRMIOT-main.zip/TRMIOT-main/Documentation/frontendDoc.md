# Documentation for Front-End

## Amplify for hosting the websites in the cloud

### Login sites with textfields, buttons, links
- Sign In
![Sign In](./Images/signin.png)

- Forgot Password
![Forgot Password](./Images/forgotpassword.png)

- Reset Password
![Reset Password](./Images/resetpassword.png)

- Update Password
![Update Password](./Images/updatepassword.png)


## Cognito for user verification, access management

